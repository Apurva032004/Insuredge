package insuredge_apurva;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.List;

public class US17P4_20T {

    WebDriver driver;

    @BeforeClass
    public void setup() throws InterruptedException {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // LOGIN
        driver.get("https://qeaskillhub.cognizant.com/LoginPage");
        Thread.sleep(1000);

        driver.findElement(By.id("txtUsername")).sendKeys("admin_user");
        driver.findElement(By.name("txtPassword"))
                .sendKeys("testadmin", Keys.ENTER);

        Thread.sleep(2000);

        // NAVIGATE TO REJECTED POLICY HOLDERS
        driver.findElement(By.xpath("//*[@id='sidebar-nav']/li[5]/a/i[2]")).click();
        Thread.sleep(600);

        driver.findElement(By.xpath("//*[@id='policyHolder-nav']/li[4]/a/span")).click();
        Thread.sleep(2000);

        // Scroll down to pagination area
        ((JavascriptExecutor) driver).executeScript("window.scroll(0,600);");
    }

    // ---------------- TC1 ----------------
    @Test(priority = 1)
    public void testPaginationControlDisplayed() {

        WebElement pagination = driver.findElement(
                By.xpath("//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']/tbody/tr[12]")
        );

        Assert.assertTrue(pagination.isDisplayed(),
                "Pagination row is NOT displayed!");

        System.out.println("TC1 : Pagination control is visible.");
    }

    // ---------------- TC2 ----------------
    @Test(priority = 2, dependsOnMethods = "testPaginationControlDisplayed")
    public void testPageNumbersDisplayed() {

        List<WebElement> pages = driver.findElements(
                By.xpath("//td[@colspan='11']/table/tbody/tr")
        );

        Assert.assertTrue(pages.size() > 0,
                "Page number controls NOT found!");

        System.out.println("Page numbers:");
        for (WebElement p : pages) {
            System.out.println(" > " + p.getText().trim());
        }

        WebElement activePage = driver.findElement(
                By.xpath("//td[@colspan='11']/table/tbody/tr/td[1]")
        );

        Assert.assertTrue(activePage.isDisplayed(),
                "Active page highlight is missing!");

        System.out.println("TC2: Page numbers + active highlight detected.");
    }

    // ---------------- TC3 ----------------
    @Test(priority = 3, dependsOnMethods = "testPageNumbersDisplayed")
    public void testPageNavigation() throws InterruptedException {

        // First row before switching page
        String before = driver.findElement(
                By.xpath("//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']/tbody/tr[2]/td[1]")
        ).getText();

        System.out.println("\nBefore switching page → " + before);

        // Click page 2 (NO try-catch!)
        WebElement page2 = driver.findElement(
                By.xpath("//td[@colspan='11']/table/tbody/tr/td[2]")
        );
        page2.click();

        Thread.sleep(2000);

        // First row after switching page
        String after = driver.findElement(
                By.xpath("//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']/tbody/tr[2]/td[1]")
        ).getText();

        System.out.println("After switching page → " + after);

        Assert.assertNotEquals(after, before,
                "Data did NOT change after clicking page 2!");
        
        
        System.out.println("TC3: Page Number is displayed.");
        System.out.println("US17P4_20: PASSED");
    }

    @AfterClass
    public void tearDown() throws InterruptedException {
        Thread.sleep(1500);
        driver.quit();
    }
}