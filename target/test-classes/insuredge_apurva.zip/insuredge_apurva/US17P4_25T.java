package insuredge_apurva;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;

public class US17P4_25T{

    WebDriver driver;
    JavascriptExecutor js;
    Actions actions;

    String tableId = "ContentPlaceHolder_Admin_gvRejectedHolders";

    @BeforeClass
    public void setup() throws Exception {

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);

        // LOGIN
        driver.get("https://qeaskillhub.cognizant.com/LoginPage");
        Thread.sleep(800);

        driver.findElement(By.id("txtUsername")).sendKeys("admin_user");
        driver.findElement(By.name("txtPassword")).sendKeys("testadmin", Keys.ENTER);
        Thread.sleep(1500);

        // Navigate → Policy Holder's → Rejected Policy Holders
        driver.findElement(By.xpath("//*[@id='sidebar-nav']/li[5]/a/i[2]")).click();
        Thread.sleep(500);

        driver.findElement(By.xpath("//*[@id='policyHolder-nav']/li[4]/a/span")).click();
        Thread.sleep(1500);

        // scroll down so table is visible
        js.executeScript("window.scrollBy(0,300)");

        // --- MUST: bring STATUS column into view (right scroll alternative) ---
        WebElement statusHeader = driver.findElement(By.xpath("//th[normalize-space()='Status']"));
        js.executeScript(
            "arguments[0].scrollIntoView({behavior:'instant', block:'nearest', inline:'end'})",
            statusHeader
        );
        Thread.sleep(800);
    }

    // ================================
    // TC1: Status cannot be edited by mouse click
    // ================================
    @Test
    public void tc1_statusNotEditableOnClick() throws Exception {
        WebElement cell = driver.findElement(By.xpath("//table[@id='"+tableId+"']/tbody/tr[2]/td[11]"));

        String before = cell.getText().trim();
        cell.click();
        Thread.sleep(500);
        String after = cell.getText().trim();

        Assert.assertEquals(after, before, "Status changed after click!");
        System.out.println("TC1 PASS: Status cannot be edited by mouse click.");
    }

    // ================================
    // TC2: Status does not allow Copy/Paste
    // ================================
    @Test(dependsOnMethods = "tc1_statusNotEditableOnClick")
    public void tc2_statusNoCopyPaste() throws Exception {
        WebElement cell = driver.findElement(By.xpath("//table[@id='"+tableId+"']/tbody/tr[2]/td[11]"));

        String before = cell.getText().trim();
        actions.click(cell)
               .sendKeys(Keys.CONTROL, "a")
               .sendKeys(Keys.CONTROL, "v")
               .perform();
        Thread.sleep(500);

        String after = cell.getText().trim();
        Assert.assertEquals(after, before, "Status changed after copy/paste!");
        System.out.println("TC2 PASS: Status does not accept copy/paste.");
    }

    // ================================
    // TC3: Typing keys should NOT update Status
    // ================================
    @Test(dependsOnMethods = "tc2_statusNoCopyPaste")
    public void tc3_statusDoesNotChangeOnTyping() throws Exception {
        WebElement cell = driver.findElement(By.xpath("//table[@id='"+tableId+"']/tbody/tr[2]/td[11]"));

        String before = cell.getText().trim();

        actions.click(cell).sendKeys("APPROVED123").perform();
        Thread.sleep(600);

        String after = cell.getText().trim();
        Assert.assertEquals(after, before, "Status changed on typing!");
        System.out.println("TC3 PASS: Status does not change on typing.");
    }

    // ================================
    // TC4: Status must remain “Rejected”
    // ================================
    @Test(dependsOnMethods = "tc3_statusDoesNotChangeOnTyping")
    public void tc4_statusAlwaysRejected() {
        WebElement cell = driver.findElement(By.xpath("//table[@id='"+tableId+"']/tbody/tr[2]/td[11]"));

        Assert.assertEquals(cell.getText().trim(), "Rejected", "Status is not 'Rejected'!");
        System.out.println("TC4 PASS: Status always remains 'Rejected'.");
    }

    // ================================
    // TC5: Hover does not change Status
    // ================================
    @Test(dependsOnMethods = "tc4_statusAlwaysRejected")
    public void tc5_statusDoesNotChangeOnHover() throws Exception {
        WebElement cell = driver.findElement(By.xpath("//table[@id='"+tableId+"']/tbody/tr[2]/td[11]"));

        String before = cell.getText().trim();
        actions.moveToElement(cell).pause(500).perform();
        Thread.sleep(500);
        String after = cell.getText().trim();

        Assert.assertEquals(after, before, "Status changed on hover!");
        System.out.println("TC5 PASS: Hover does not change Status.");
    }

    // ================================
    // TC6: No UI option to change Status icon/menu/button
    // ================================
    @Test(dependsOnMethods = "tc5_statusDoesNotChangeOnHover")
    public void tc6_noUiToChangeStatus() {

        // Check header for any icon/button
        int headerControls = driver.findElements(
                By.xpath("//th[normalize-space()='Status']//button | //th[normalize-space()='Status']//a | //th[normalize-space()='Status']//i")
        ).size();

        // Check cell for any UI element (edit icon/link)
        int cellControls = driver.findElements(
                By.xpath("//table[@id='"+tableId+"']//tbody/tr[2]/td[11]//a | //table[@id='"+tableId+"']//tbody/tr[2]/td[11]//button")
        ).size();

        Assert.assertEquals(headerControls, 0, "Editable UI element found in header!");
        Assert.assertEquals(cellControls, 0, "Editable UI element found in Status cell!");

        System.out.println("TC6 PASS: No UI element allows changing Status.");
        System.out.println();
         System.out.println("US17P4_25: PASSED");
    }

    @AfterClass
    public void tearDown() throws Exception {
        Thread.sleep(800);
        driver.quit();
    }
}
