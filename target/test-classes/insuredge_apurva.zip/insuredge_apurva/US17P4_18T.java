package insuredge_apurva;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.Arrays;
import java.util.List;

public class US17P4_18T{

    private WebDriver driver;
    private JavascriptExecutor js;

    // Exact headers to validate (text must match UI exactly)
    private static final List<String> HEADERS_TO_CHECK = Arrays.asList(
            "Customer Name",
            "Mobile Number",
            "Email",
            "Policy Name",
            "Main Category",
            "Sub Category",
            "Sum Assured",
            "Premium",
            "Tenure",
            "Applied On",
            "Status"
    );

    @BeforeClass
    public void setup() throws InterruptedException {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        js = (JavascriptExecutor) driver;

        // ===== LOGIN =====
        driver.get("https://qeaskillhub.cognizant.com/LoginPage");
        Thread.sleep(800);
        driver.findElement(By.id("txtUsername")).sendKeys("admin_user");
        driver.findElement(By.name("txtPassword")).sendKeys("testadmin", Keys.ENTER);
        Thread.sleep(1400);

        // ===== NAVIGATE: Policy Holder's → Rejected Policy Holders =====
        driver.findElement(By.xpath("//*[@id='sidebar-nav']/li[5]/a/i[2]")).click();
        Thread.sleep(500);
        driver.findElement(By.xpath("//*[@id='policyHolder-nav']/li[4]/a/span")).click();
        Thread.sleep(1200);
    }

    @Test(priority = 1, description = "T01: Scroll RIGHT to reveal the 'Status' header (no vertical scroll)")
    public void T01_scrollRightToStatus() throws InterruptedException {
        // Prefer the exact Status <th>; fallback to first-row header cell if needed
        WebElement statusHeader;
        try {
            statusHeader = driver.findElement(By.xpath(
                    "//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']//th[normalize-space()='Status']"));
        } catch (NoSuchElementException e) {
            statusHeader = driver.findElement(By.xpath(
                    "//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']//tr[1]/*[self::th or self::td][normalize-space()='Status']"));
        }

        // Horizontal-only reveal (keeps vertical position)
        js.executeScript(
                "arguments[0].scrollIntoView({behavior:'instant', block:'nearest', inline:'end'})",
                statusHeader
        );
        Thread.sleep(600);

        // Assert Status header is displayed after horizontal reveal
        Assert.assertTrue(statusHeader.isDisplayed(), "'Status' header is not visible after horizontal scroll.");
        System.out.println("TC01: Scroll RIGHT to reveal the 'Status' header");
    }

    @Test(priority = 2, dependsOnMethods = "T01_scrollRightToStatus",
          description = "T02: Verify all specified header names are present")
    public void T02_allSpecifiedHeadersPresent() {
        for (String headerText : HEADERS_TO_CHECK) {
            WebElement headerEl = null;

            // Try <th> with exact label
            try {
                headerEl = driver.findElement(By.xpath(
                        "//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']//th[normalize-space()='" + headerText + "']"));
            } catch (NoSuchElementException ignore) {
                // Fallback to first-row header cell (th/td)
                try {
                    headerEl = driver.findElement(By.xpath(
                            "//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']//tr[1]/*[self::th or self::td][normalize-space()='" + headerText + "']"));
                } catch (NoSuchElementException e2) {
                    Assert.fail("Header not found: '" + headerText + "'");
                }
            }

            Assert.assertNotNull(headerEl, "Header WebElement is null for: " + headerText);
            Assert.assertTrue(headerEl.isDisplayed(), "Header not displayed: " + headerText);
            //System.out.println("TC02: Verify all specified header names are present");
        }
    }

    @Test(priority = 3, dependsOnMethods = "T02_allSpecifiedHeadersPresent",
          description = "T03: Verify all specified header names are BOLD (font-weight >= 700 or 'bold')")
    public void T03_allSpecifiedHeadersAreBold() {
        boolean allBold = true;
        StringBuilder nonBoldList = new StringBuilder();

        for (String headerText : HEADERS_TO_CHECK) {
            WebElement headerEl = null;

            // Prefer <th>, otherwise try first row header cell
            try {
                headerEl = driver.findElement(By.xpath(
                        "//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']//th[normalize-space()='" + headerText + "']"));
            } catch (NoSuchElementException ignore) {
                try {
                    headerEl = driver.findElement(By.xpath(
                            "//table[@id='ContentPlaceHolder_Admin_gvRejectedHolders']//tr[1]/*[self::th or self::td][normalize-space()='" + headerText + "']"));
                } catch (NoSuchElementException e2) {
                    Assert.fail("Header not found (for bold check): '" + headerText + "'");
                }
            }

            String fw = headerEl.getCssValue("font-weight"); // e.g., "700" or "bold"
            boolean isBold;
            try {
                int numeric = Integer.parseInt(fw.replaceAll("[^0-9]", ""));
                isBold = numeric >= 700;
            } catch (NumberFormatException e3) {
                isBold = "bold".equalsIgnoreCase(fw);
            }

            if (!isBold) {
                allBold = false;
                nonBoldList.append("Header '").append(headerText).append("' font-weight=").append(fw).append("\n");
            }
        }

        Assert.assertTrue(allBold, "Some headers are not bold:\n" + nonBoldList);
        System.out.println("TC03:Verify all specified header names are BOLD ");
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() throws InterruptedException {
        Thread.sleep(600);
        if (driver != null) driver.quit();
    }
}